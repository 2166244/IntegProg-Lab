package ticketingsystem;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.RemoteObject;
import java.rmi.server.UnicastRemoteObject;

   public class Server extends RemoteObject implements TicketingSystem {
        int madrid = 3;
        int london = 3;
        int krakow = 3;

        public static void main(String[] args) {
            try { 
                TicketingSystem obj = new Server();           
                TicketingSystem stub = (TicketingSystem) UnicastRemoteObject.exportObject( obj , 0);
                Registry registry = LocateRegistry.createRegistry(1098);
                registry.bind("RemoteObject", stub);

                System.out.println("Server running...");

                } 
            catch (AlreadyBoundException | RemoteException e) { 
                System.err.println("Server error: " + e.getMessage()); 
            }
        }

        @Override
        public int setEvent(int journey) {
            if (journey > 3) {
                System.out.println("Error, press number between 1 and 3");
            } else {
                checkAvailable(journey);
            }

            return journey;
        }

        @Override
        public void checkAvailable(int journey) {
            switch (journey) {
                case 1:
                    if (madrid != 0) {
                        madrid--;
                        System.out.println("Journey to madrid booked");
                        System.out.println("Number of tickets left for madrid : " + madrid);
                    }   break;
                case 2:
                    if (london != 0) {
                        london--;
                        System.out.println("Journey to london booked");
                        System.out.println("Number of tickets left for london : " + london);
                    }   break;
                case 3:
                    if (krakow != 0) {
                        krakow--;
                        System.out.println("Journey to krakow booked");
                        System.out.println("Number of tickets left for krakow : " + krakow);
                    }   break;
                default:
                    break;
            }

        }

        }
