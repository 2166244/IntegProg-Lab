
package ticketingsystem;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface TicketingSystem extends Remote {
    int setEvent(int destination) throws RemoteException;
    void checkAvailable(int journey) throws RemoteException;
}
