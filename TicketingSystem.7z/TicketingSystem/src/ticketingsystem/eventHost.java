package ticketingsystem;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class eventHost {

private eventHost() {

}

public static void main(String[] args) {
    int message; 
    TicketingSystem obj = null; 
    try { 
        Registry registry = LocateRegistry.getRegistry("localhost", 1098);
        obj = (TicketingSystem) registry.lookup("RemoteObject");
        
            System.out.println("------------------------------------------------");
            System.out.println(" 1. Add an event ");
            System.out.println(" 2. Exit ");
            System.out.println("------------------------------------------------");
            
            Scanner consoleIn = new Scanner(System.in);
            int choice = consoleIn.nextInt();
            
                if(choice == 2) {
                    System.exit(0);
                }
            message = obj.setEvent(choice);
            
            /**System.out.println("Press 1 for Madrid");
            System.out.println("Press 2 for London");
            System.out.println("Press 3 for Krakow");
            System.out.println("Press 9 to exit");

            int numEntered;
            Scanner scan = new Scanner(System.in);
            numEntered = scan.nextInt();

            if (numEntered == 9) {
                break;
            }
            message = obj.bookTicket(numEntered);
            System.out.println(message);**/

    } catch (Exception e) { 
        System.out.println("Client exception: " + e.getMessage()); 
        e.printStackTrace(); 
        }
    }
}